-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2023 at 06:02 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coba lagi`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Daftar_Pembeli_Bulan_Maret` ()   BEGIN
    SELECT `pelanggan`.`Nama Pelanggan`, `pelanggan`.`Kode Pelanggan`, `transaksi pelanggan`.`Jumlah Transaksi`
    FROM `transaksi pelanggan`
INNER JOIN `Pelanggan` ON `transaksi pelanggan`.`Kode Pelanggan`=`pelanggan`.`Kode Pelanggan`
    WHERE `Tanggal Transaksi` BETWEEN '2023-03-01' AND '2023-03-31';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Diligent_Employee` ()   BEGIN
    SELECT `karyawan`.`Nama Karyawan`, `transaksi publik`.`Kode Karyawan`, `transaksi publik`.`Jumlah Transaksi` AS `Jumlah Obat yang dijual`
    FROM `transaksi publik`
INNER JOIN `karyawan` ON `transaksi publik`.`Kode Karyawan`=`karyawan`.`Kode Karyawan`
    WHERE `Tanggal Transaksi` BETWEEN '2023-04-01' AND '2023-04-31';
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `countStaff` () RETURNS INT(11)  BEGIN
    DECLARE staffCount INT;
    SELECT COUNT(DISTINCT `Kode Karyawan`) INTO staffCount FROM `karyawan`;
    RETURN staffCount;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `sumStockObat` () RETURNS INT(11)  BEGIN
    DECLARE totalSum INT;
    SELECT SUM(`Stock`) INTO totalSum FROM `inventory display`;
    RETURN totalSum;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `sumtotalpembelian` () RETURNS INT(11)  BEGIN
    DECLARE totalSum INT;
    SELECT SUM(`Jumlah Transaksi`) INTO totalSum FROM `transaksi pelanggan`;
    RETURN totalSum;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `inventory display`
--

CREATE TABLE `inventory display` (
  `Nama Obat` char(50) DEFAULT NULL,
  `Kode Obat` varchar(255) NOT NULL,
  `Stock` int(11) DEFAULT NULL,
  `Tanggal Produksi` date DEFAULT NULL,
  `Tanggal Kadaluarsa` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory display`
--

INSERT INTO `inventory display` (`Nama Obat`, `Kode Obat`, `Stock`, `Tanggal Produksi`, `Tanggal Kadaluarsa`) VALUES
('Paracetamol', 'KO001', 50, '2023-01-01', '2024-01-01'),
('Ibuprofen', 'KO002', 30, '2023-01-02', '2024-01-02'),
('Aspirin', 'KO003', 25, '2023-01-03', '2024-01-03'),
('Amoxicillin', 'KO004', 40, '2023-01-04', '2024-01-04'),
('Cetirizine', 'KO005', 20, '2023-01-05', '2024-01-05'),
('Omeprazole', 'KO006', 35, '2023-01-06', '2024-01-06'),
('Loratadine', 'KO007', 45, '2023-01-07', '2024-01-07'),
('Simvastatin', 'KO008', 22, '2023-01-08', '2024-01-08'),
('Metformin', 'KO009', 38, '2023-01-09', '2024-01-09'),
('Losartan', 'KO010', 33, '2023-01-10', '2024-01-10'),
('Atorvastatin', 'KO011', 28, '2023-01-11', '2024-01-11'),
('Gabapentin', 'KO012', 42, '2023-01-12', '2024-01-12'),
('Clopidogrel', 'KO013', 19, '2023-01-13', '2024-01-13'),
('Diazepam', 'KO014', 31, '2023-01-14', '2024-01-14'),
('Metoprolol', 'KO015', 37, '2023-01-15', '2024-01-15'),
('Prednisone', 'KO016', 26, '2023-01-16', '2024-01-16'),
('Furosemide', 'KO017', 40, '2023-01-17', '2024-01-17'),
('Tamsulosin', 'KO018', 23, '2023-01-18', '2024-01-18'),
('Warfarin', 'KO019', 29, '2023-01-19', '2024-01-19'),
('Escitalopram', 'KO020', 34, '2023-01-20', '2024-01-20'),
('Ranitidine', 'KO021', 27, '2023-01-21', '2024-01-21'),
('Cephalexin', 'KO022', 36, '2023-01-22', '2024-01-22'),
('Amlodipine', 'KO023', 24, '2023-01-23', '2024-01-23'),
('Clonazepam', 'KO024', 32, '2023-01-24', '2024-01-24'),
('Venlafaxine', 'KO025', 41, '2023-01-25', '2024-01-25'),
('Levothyroxine', 'KO026', 18, '2023-01-26', '2024-01-26'),
('Hydrochlorothiazide', 'KO027', 39, '2023-01-27', '2024-01-27'),
('Methotrexate', 'KO028', 21, '2023-01-28', '2024-01-28'),
('Fluoxetine', 'KO029', 44, '2023-01-29', '2024-01-29'),
('Albuterol', 'KO030', 30, '2023-01-30', '2024-01-30');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_langganan`
--

CREATE TABLE `inventory_langganan` (
  `Nama_Obat` char(50) DEFAULT NULL,
  `Kode_Obat` varchar(255) NOT NULL,
  `Stock` int(11) DEFAULT NULL,
  `Tanggal_Produksi` date DEFAULT NULL,
  `Tanggal_Kadaluarsa` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_langganan`
--

INSERT INTO `inventory_langganan` (`Nama_Obat`, `Kode_Obat`, `Stock`, `Tanggal_Produksi`, `Tanggal_Kadaluarsa`) VALUES
('EKG Machine', 'KA001', 5, '2023-02-15', NULL),
('MRI Scanner', 'KA002', 3, '2023-02-16', NULL),
('X-ray Machine', 'KA003', 7, '2023-02-17', NULL),
('Ultrasound Machine', 'KA004', 4, '2023-02-18', NULL),
('Defibrillator', 'KA005', 6, '2023-02-19', NULL),
('Anesthesia Machine', 'KA006', 2, '2023-02-20', NULL),
('Ventilator', 'KA007', 8, '2023-02-21', NULL),
('Blood Pressure Monitor', 'KA008', 10, '2023-02-22', NULL),
('Surgical Lights', 'KA009', 3, '2023-02-23', NULL),
('Autoclave', 'KA010', 4, '2023-02-24', NULL),
('Hospital Bed', 'KA011', 15, '2023-02-25', NULL),
('Wheelchair', 'KA012', 20, '2023-02-26', NULL),
('Stethoscope', 'KA013', 25, '2023-02-27', NULL),
('Oxygen Concentrator', 'KA014', 5, '2023-02-28', NULL),
('Nebulizer', 'KA015', 7, '2023-03-01', NULL),
('Blood Glucose Monitor', 'KA016', 12, '2023-03-02', NULL),
('Crutches', 'KA017', 10, '2023-03-03', NULL),
('Hospital Gown', 'KA018', 30, '2023-03-04', NULL),
('Surgical Mask', 'KA019', 50, '2023-03-05', NULL),
('Gloves', 'KA020', 100, '2023-03-06', NULL),
('Paracetamol', 'KL001', 200, '2023-01-01', '2024-01-01'),
('Ibuprofen', 'KL002', 150, '2023-01-02', '2024-01-02'),
('Aspirin', 'KL003', 180, '2023-01-03', '2024-01-03'),
('Amoxicillin', 'KL004', 120, '2023-01-04', '2024-01-04'),
('Cetirizine', 'KL005', 250, '2023-01-05', '2024-01-05'),
('Acetaminophen', 'KL006', 300, '2023-01-06', '2024-01-06'),
('Doxycycline', 'KL007', 180, '2023-01-07', '2024-01-07'),
('Naproxen', 'KL008', 220, '2023-01-08', '2024-01-08'),
('Mirtazapine', 'KL009', 190, '2023-01-09', '2024-01-09'),
('Carvedilol', 'KL010', 270, '2023-01-10', '2024-01-10'),
('Propranolol', 'KL011', 230, '2023-01-11', '2024-01-11'),
('Ciprofloxacin', 'KL012', 280, '2023-01-12', '2024-01-12'),
('Sertraline', 'KL013', 320, '2023-01-13', '2024-01-13'),
('Trazodone', 'KL014', 190, '2023-01-14', '2024-01-14'),
('Lisinopril', 'KL015', 260, '2023-01-15', '2024-01-15'),
('Paracetamol', 'KL016', 200, '2023-01-16', '2024-01-16'),
('Ibuprofen', 'KL017', 150, '2023-01-17', '2024-01-17'),
('Aspirin', 'KL018', 180, '2023-01-18', '2024-01-18'),
('Amoxicillin', 'KL019', 120, '2023-01-19', '2024-01-19'),
('Cetirizine', 'KL020', 250, '2023-01-20', '2024-01-20'),
('Acetaminophen', 'KL021', 300, '2023-02-01', '2024-02-01'),
('Doxycycline', 'KL022', 180, '2023-02-02', '2024-02-02'),
('Naproxen', 'KL023', 220, '2023-02-03', '2024-02-03'),
('Mirtazapine', 'KL024', 190, '2023-02-04', '2024-02-04'),
('Carvedilol', 'KL025', 270, '2023-02-05', '2024-02-05'),
('Propranolol', 'KL026', 230, '2023-02-06', '2024-02-06'),
('Ciprofloxacin', 'KL027', 280, '2023-02-07', '2024-02-07'),
('Sertraline', 'KL028', 320, '2023-02-08', '2024-02-08'),
('Trazodone', 'KL029', 190, '2023-02-09', '2024-02-09'),
('Lisinopril', 'KL030', 260, '2023-02-10', '2024-02-10');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `Nama Karyawan` char(255) DEFAULT NULL,
  `Kode Karyawan` varchar(255) NOT NULL,
  `Jabatan` char(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`Nama Karyawan`, `Kode Karyawan`, `Jabatan`) VALUES
('Agatha', 'NK001', 'Manager Apotek'),
('Dean', 'NK002', 'Peneliti Obat'),
('Bram', 'NK003', 'Spesialis Obat'),
('Ferdinand', 'NK004', 'Peneliti Obat'),
('Thomas', 'NK005', 'Penasehat Obat'),
('Tian', 'NK006', 'Apoteker'),
('Dedy', 'NK007', 'Apoteker'),
('Priskila', 'NK008', 'Apoteker'),
('Lily', 'NK009', 'Asisten Apotek'),
('Danny', 'NK010', 'Asisten Apotek');

-- --------------------------------------------------------

--
-- Stand-in structure for view `melihat daftar karyawan`
-- (See below for the actual view)
--
CREATE TABLE `melihat daftar karyawan` (
`Jabatan` char(255)
,`Nama Karyawan` char(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `melihat daftar obat`
-- (See below for the actual view)
--
CREATE TABLE `melihat daftar obat` (
`Kode Obat` varchar(255)
,`Nama Obat` char(50)
,`Stock` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `melihat daftar pelanggan`
-- (See below for the actual view)
--
CREATE TABLE `melihat daftar pelanggan` (
`Nama Pelanggan` char(255)
,`Alamat Pelanggan` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `Nama Pelanggan` char(255) DEFAULT NULL,
  `Kode Pelanggan` varchar(255) NOT NULL,
  `Alamat Pelanggan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`Nama Pelanggan`, `Kode Pelanggan`, `Alamat Pelanggan`) VALUES
('Klinik Sarangan Medicare', 'RS001', 'Jl. Sarangan No. 11'),
('Klinik Bunga Melati Panjaitan', 'RS002', 'Jl. Mayjend Panjaitan No. 247'),
('Klinik Rawat Inap Amanah Husada', 'RS003', 'Jl. Kalpataru No. 20'),
('Sanan Medika Clinic', 'RS004', 'Jl. Tumenggung Suryo No. 92'),
('Brawijaya University Clinic', 'RS005', 'Jl. MT. Haryono'),
('Lavalette General Hospital', 'RS006', 'Jl. W.R Supratman No. 10'),
('RSUD Dr. Saiful Answar', 'RS007', 'Jl. Jaksa Agung Suprapto No. 2'),
('RSIA Mutiara Bunda', 'RS008', 'Jl. Ciujung No. 19'),
('RSU BRIMEDIKA Malang', 'RS009', 'Jl. Mayjend Panjaitan No. 176'),
('Hermina Hospital', 'RS010', 'Jl. Tangkuban Perahu No. 31-33');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi pelanggan`
--

CREATE TABLE `transaksi pelanggan` (
  `Kode Transaksi` varchar(255) NOT NULL,
  `Kode Pelanggan` varchar(255) DEFAULT NULL,
  `Kode_Obat` varchar(255) DEFAULT NULL,
  `Tanggal Transaksi` date DEFAULT NULL,
  `Jumlah Transaksi` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi pelanggan`
--

INSERT INTO `transaksi pelanggan` (`Kode Transaksi`, `Kode Pelanggan`, `Kode_Obat`, `Tanggal Transaksi`, `Jumlah Transaksi`) VALUES
('TR001', 'RS001', 'KA001', '2023-02-01', 10),
('TR0010', 'RS003', 'KA009', '2023-02-11', 11),
('TR0011', 'RS003', 'KA009', '2023-02-13', 13),
('TR0012', 'RS003', 'KA009', '2023-02-14', 9),
('TR0013', 'RS004', 'KA011', '2023-02-15', 15),
('TR0014', 'RS004', 'KA003', '2023-02-17', 18),
('TR0015', 'RS004', 'KA014', '2023-02-18', 12),
('TR0016', 'RS005', 'KA015', '2023-02-19', 20),
('TR0017', 'RS005', 'KA016', '2023-02-20', 14),
('TR0018', 'RS005', 'KA017', '2023-02-21', 16),
('TR0019', 'RS005', 'KA018', '2023-02-22', 19),
('TR002', 'RS001', 'KA002', '2023-02-02', 15),
('TR0020', 'RS008', 'KL019', '2023-02-23', 11),
('TR0021', 'RS008', 'KL020', '2023-02-24', 13),
('TR0022', 'RS004', 'KA010', '2023-02-25', 14),
('TR0023', 'RS004', 'KA012', '2023-02-26', 9),
('TR0024', 'RS004', 'KA013', '2023-02-27', 16),
('TR0025', 'RS004', 'KA007', '2023-02-28', 12),
('TR0026', 'RS008', 'KL015', '2023-03-01', 18),
('TR0027', 'RS008', 'KL016', '2023-03-02', 11),
('TR0028', 'RS009', 'KL009', '2023-03-03', 15),
('TR0029', 'RS009', 'KL015', '2023-03-04', 18),
('TR003', 'RS001', 'KA003', '2023-02-03', 8),
('TR0030', 'RS009', 'KL017', '2023-03-05', 18),
('TR0031', 'RS009', 'KL018', '2023-03-02', 11),
('TR0032', 'RS006', 'KA001', '2023-03-07', 17),
('TR0033', 'RS006', 'KA002', '2023-03-08', 10),
('TR0034', 'RS006', 'KA003', '2023-03-09', 20),
('TR0035', 'RS006', 'KA004', '2023-03-10', 16),
('TR0036', 'RS007', 'KA005', '2023-03-11', 15),
('TR0037', 'RS007', 'KA006', '2023-03-12', 12),
('TR0038', 'RS007', 'KA007', '2023-03-13', 18),
('TR0039', 'RS007', 'KA008', '2023-03-14', 14),
('TR004', 'RS001', 'KA004', '2023-02-04', 12),
('TR0040', 'RS007', 'KA009', '2023-03-15', 13),
('TR0041', 'RS010', 'KL001', '2023-05-01', 3),
('TR0042', 'RS010', 'KL012', '2023-06-01', 21),
('TR0043', 'RS010', 'KL002', '2023-08-02', 8),
('TR0044', 'RS010', 'KL007', '2023-09-03', 30),
('TR005', 'RS002', 'KA005', '2023-02-07', 7),
('TR006', 'RS002', 'KA005', '2023-02-08', 11),
('TR007', 'RS002', 'KA006', '2023-02-09', 18),
('TR008', 'RS002', 'KA007', '2023-02-09', 3),
('TR009', 'RS003', 'KA009', '2023-02-11', 17);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi publik`
--

CREATE TABLE `transaksi publik` (
  `Kode Transaksi` varchar(255) NOT NULL,
  `Kode Karyawan` varchar(255) DEFAULT NULL,
  `Kode Obat` varchar(255) DEFAULT NULL,
  `Tanggal Transaksi` date DEFAULT NULL,
  `Jumlah Transaksi` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi publik`
--

INSERT INTO `transaksi publik` (`Kode Transaksi`, `Kode Karyawan`, `Kode Obat`, `Tanggal Transaksi`, `Jumlah Transaksi`) VALUES
('TR001', 'NK001', 'KO013', '2023-03-04', '11'),
('TR0010', 'NK003', 'KO013', '2023-04-21', '17'),
('TR0011', 'NK003', 'KO017', '2023-04-26', '22'),
('TR0012', 'NK005', 'KO009', '2023-06-13', '14'),
('TR0014', 'NK004', 'KO007', '2023-05-12', '7'),
('TR0015', 'NK004', 'KO008', '2023-04-28', '2'),
('TR0016', 'NK004', 'KO009', '2023-05-23', '14'),
('TR0017', 'NK005', 'KO003', '2023-05-29', '11'),
('TR0018', 'NK005', 'KO001', '2023-06-03', '7'),
('TR0019', 'NK005', 'KO010', '2023-06-07', '30'),
('TR002', 'NK001', 'KO017', '2023-03-08', '9'),
('TR0021', 'NK006', 'KO023', '2023-05-21', '17'),
('TR0022', 'NK006', 'KO024', '2023-06-23', '44'),
('TR0023', 'NK006', 'KO022', '2023-07-01', '5'),
('TR0024', 'NK006', 'KO027', '2023-07-06', '3'),
('TR0025', 'NK007', 'KO029', '2023-07-18', '3'),
('TR0026', 'NK007', 'KO028', '2023-07-29', '14'),
('TR0027', 'NK007', 'KO025', '2023-08-01', '21'),
('TR0028', 'NK007', 'KO026', '2023-08-06', '19'),
('TR0029', 'NK008', 'KO022', '2023-08-11', '5'),
('TR003', 'NK001', 'KO001', '2023-03-14', '1'),
('TR0030', 'NK008', 'KO023', '2023-08-17', '16'),
('TR0031', 'NK008', 'KO027', '2023-09-03', '37'),
('TR0032', 'NK008', 'KO024', '2023-09-04', '21'),
('TR0033', 'NK009', 'KO018', '2023-09-08', '8'),
('TR0034', 'NK009', 'KO012', '2023-09-11', '18'),
('TR0035', 'NK009', 'KO023', '2023-10-10', '11'),
('TR0036', 'NK009', 'KO014', '2023-10-14', '13'),
('TR0037', 'NK010', 'KO028', '2023-11-08', '11'),
('TR0038', 'NK010', 'KO002', '2023-11-22', '21'),
('TR0039', 'NK010', 'KO013', '2023-12-03', '15'),
('TR004', 'NK001', 'KO006', '2023-03-20', '22'),
('TR0040', 'NK010', 'KO004', '2023-12-24', '19'),
('TR005', 'NK002', 'KO021', '2023-03-25', '7'),
('TR006', 'NK002', 'KO003', '2023-03-29', '21'),
('TR007', 'NK002', 'KO002', '2023-04-05', '14'),
('TR008', 'NK002', 'KO002', '2023-04-10', '33'),
('TR009', 'NK003', 'KO018', '2023-04-16', '10'),
('TR013', 'NK004', 'KO011', '2023-04-13', '19');

-- --------------------------------------------------------

--
-- Structure for view `melihat daftar karyawan`
--
DROP TABLE IF EXISTS `melihat daftar karyawan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `melihat daftar karyawan`  AS SELECT `karyawan`.`Jabatan` AS `Jabatan`, `karyawan`.`Nama Karyawan` AS `Nama Karyawan` FROM `karyawan` ;

-- --------------------------------------------------------

--
-- Structure for view `melihat daftar obat`
--
DROP TABLE IF EXISTS `melihat daftar obat`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `melihat daftar obat`  AS SELECT `inventory display`.`Kode Obat` AS `Kode Obat`, `inventory display`.`Nama Obat` AS `Nama Obat`, `inventory display`.`Stock` AS `Stock` FROM `inventory display` ;

-- --------------------------------------------------------

--
-- Structure for view `melihat daftar pelanggan`
--
DROP TABLE IF EXISTS `melihat daftar pelanggan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `melihat daftar pelanggan`  AS SELECT `pelanggan`.`Nama Pelanggan` AS `Nama Pelanggan`, `pelanggan`.`Alamat Pelanggan` AS `Alamat Pelanggan` FROM `pelanggan` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory display`
--
ALTER TABLE `inventory display`
  ADD PRIMARY KEY (`Kode Obat`);

--
-- Indexes for table `inventory_langganan`
--
ALTER TABLE `inventory_langganan`
  ADD PRIMARY KEY (`Kode_Obat`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`Kode Karyawan`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`Kode Pelanggan`);

--
-- Indexes for table `transaksi pelanggan`
--
ALTER TABLE `transaksi pelanggan`
  ADD PRIMARY KEY (`Kode Transaksi`),
  ADD KEY `Kode_Obat` (`Kode_Obat`),
  ADD KEY `Kode Pelanggan` (`Kode Pelanggan`);

--
-- Indexes for table `transaksi publik`
--
ALTER TABLE `transaksi publik`
  ADD PRIMARY KEY (`Kode Transaksi`),
  ADD KEY `Kode Obat` (`Kode Obat`),
  ADD KEY `Kode Karyawan` (`Kode Karyawan`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi pelanggan`
--
ALTER TABLE `transaksi pelanggan`
  ADD CONSTRAINT `transaksi pelanggan_ibfk_1` FOREIGN KEY (`Kode_Obat`) REFERENCES `inventory_langganan` (`Kode_Obat`),
  ADD CONSTRAINT `transaksi pelanggan_ibfk_2` FOREIGN KEY (`Kode Pelanggan`) REFERENCES `pelanggan` (`Kode Pelanggan`);

--
-- Constraints for table `transaksi publik`
--
ALTER TABLE `transaksi publik`
  ADD CONSTRAINT `transaksi publik_ibfk_1` FOREIGN KEY (`Kode Obat`) REFERENCES `inventory display` (`Kode Obat`),
  ADD CONSTRAINT `transaksi publik_ibfk_2` FOREIGN KEY (`Kode Karyawan`) REFERENCES `karyawan` (`Kode Karyawan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
